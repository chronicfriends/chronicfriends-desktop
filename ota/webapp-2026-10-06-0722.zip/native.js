/* ===== Capa nativa (solo runtime) =====================================
   Marca que la app corre dentro del envoltorio nativo y da comportamiento
   de app (sin selección de texto ni menús de long-press del navegador).
   Aditiva: no toca el código del diseño. */
(function () {
  window.__CF_NATIVE__ = true;

  /* comportamiento de app, no de página web */
  var st = document.documentElement.style;
  st.webkitUserSelect = 'none';
  st.userSelect = 'none';
  st.webkitTouchCallout = 'none';

  /* los inputs sí deben permitir selección/edición normal */
  var css = document.createElement('style');
  css.textContent = 'input, textarea, [contenteditable] { -webkit-user-select: text !important; user-select: text !important; }';
  document.head.appendChild(css);
})();

/* ===== Purga de los usuarios de prueba (Test 1..Test 5) ==================
   Hasta el 4 ago 2026 aquí vivía la SIEMBRA de demo: 5 amigos falsos
   (test1..test5@chronicfriends.app), 7 posts suyos en el feed y chats DM
   inventados, que se inyectaban a TODO usuario con sesión. Decisión de
   Gerhard (4 ago 2026): fuera antes de que lleguen usuarios reales.

   Este bloque hace lo inverso y es idempotente: en dispositivos donde la
   siembra ya corrió, la elimina; en dispositivos nuevos no hay nada que
   hacer. Se puede retirar en algún build futuro cuando ya no queden
   instalaciones antiguas.
   • Posts sembrados → ids fijos 'seedtu-*' en el store global cf_posts_v1
     (via CFPosts.userPosts + emit()).
   • Perfiles de los Test → claves cfns:pat:testN@chronicfriends.app:* en
     localStorage (cf_profile_v1 y cualquier otra de ese namespace).
   • Chats DM con los Test → entradas de CFChat.data del usuario actual con
     uid pat:testN@chronicfriends.app (+ emit()).
   • Centinelas cf_seed_testusers_v1 (globales o namespaceadas).
   No toca NADA más: posts reales, chats reales y perfiles reales quedan
   exactamente igual. */
(function () {
  var LS = window.localStorage;
  var TEST_UIDS = [1, 2, 3, 4, 5].map(function (n) { return 'pat:test' + n + '@chronicfriends.app'; });

  function purgeLocalStorageKeys() {
    var doomed = [];
    for (var i = 0; i < LS.length; i++) {
      var k = LS.key(i);
      if (!k) continue;
      var isTestNs = TEST_UIDS.some(function (uid) { return k.indexOf('cfns:' + uid + ':') === 0; });
      var isSentinel = k === 'cf_seed_testusers_v1' || /(^|:)cf_seed_testusers_v1$/.test(k);
      if (isTestNs || isSentinel) doomed.push(k);
    }
    doomed.forEach(function (k) { try { LS.removeItem(k); } catch (e) {} });
    return doomed.length;
  }

  function purgePosts() {
    var CFPosts = window.CFPosts;
    if (!CFPosts || !Array.isArray(CFPosts.userPosts)) return false;
    var before = CFPosts.userPosts.length;
    var clean = CFPosts.userPosts.filter(function (p) {
      if (!p) return false;
      if (p.id && String(p.id).indexOf('seedtu-') === 0) return false;
      if (p.author && TEST_UIDS.indexOf(p.author) !== -1) return false;
      return true;
    });
    if (clean.length === before) return false;
    CFPosts.userPosts = clean;
    try { CFPosts.emit(); } catch (e) {}               /* persiste a cf_posts_v1 + notifica */
    return true;
  }

  function purgeChats() {
    var CFChat = window.CFChat;
    if (!CFChat || !CFChat.data) return false;
    var changed = false;
    TEST_UIDS.forEach(function (uid) {
      if (CFChat.data[uid]) { delete CFChat.data[uid]; changed = true; }
    });
    if (changed) { try { CFChat.emit(); } catch (e) {} } /* persiste a cfns:<uid>:cf_chats_v1 */
    return changed;
  }

  /* Corre cuando los stores están listos; las claves de localStorage se
     pueden limpiar desde el primer momento. Poll corto como el que usaba
     la siembra: la app recarga tras el login y los stores tardan en abrir. */
  function tryPurge() {
    purgeLocalStorageKeys();
    if (!window.CFPosts || !window.CFChat) return false;
    purgePosts();
    purgeChats();
    return true;
  }

  var tries = 0, handle = null;
  function tick() {
    if (tryPurge() || tries > 80) { if (handle) { clearInterval(handle); handle = null; } }
    tries++;
  }
  function start() { if (!handle) { tries = 0; handle = setInterval(tick, 700); } tick(); }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  } else {
    start();
  }
  window.addEventListener('storage', function (e) { if (e && e.key === 'cf_auth_v1') start(); });
})();
